import SweetAlert from './SweetAlert.js'

const Swal = SweetAlert
// @ts-ignore
Swal.default = Swal

export default Swal
